ServerEvents.recipes((event) => {
  // Removing the steel SHEETS pressing script
  event.remove({ id: "alloyed:pressing/steel_sheet" });

  // Adding a recipe for pressing 'any.forge.steel' into overgeared's steel plates
  event.recipes.create.pressing(
    "overgeared:steel_plate",
    "overgeared:steel_ingot",
  );
  event.recipes.create.pressing(
    "overgeared:steel_plate",
    "alloyed:steel_ingot",
  );

  //   event.shaped(
  //     Item.of(
  //       "minecraft:golden_sword",
  //       '{Damage:15,Unbreakable:1b,Enchantments:[{id:"minecraft:sharpness",lvl:15s},{id:"minecraft:looting",lvl:10s}],display:{Name:\'{"text":"God Sword","color":"gold"}\'}}',
  //     ),
  //     ["G", "S", "S"],
  //     {
  //       G: "minecraft:golden_sword",
  //       S: "minecraft:stick",
  //     },
  //   );
});
